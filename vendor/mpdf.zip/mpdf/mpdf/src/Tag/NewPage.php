<?php

namespace Mpdf\Tag;

class NewPage extends FormFeed
{

}
